
function login(req, res){
    //do login shit
    //send session to user
    //redirect to home page
    
    res.status(200).send({ message : "Hello Login"});
}

function logout(req, res){
    //delete the session
    //redirect page to login
    res.status(200).send({ message : "Hello Logout"});
}


export default {
    login,
    logout
}